package ObserverPattern;

public interface Observer {

	void updateObserver(String notificacao);

}